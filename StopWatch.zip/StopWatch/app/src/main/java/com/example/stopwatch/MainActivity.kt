package com.example.stopwatch

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var isRunning = false
    private var startTime = 0L
    private var elapsedTime = 0L
    private lateinit var tvTimer: TextView
    private lateinit var btnStart: Button
    private lateinit var btnPause: Button
    private lateinit var btnReset: Button
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvTimer = findViewById(R.id.tvTimer)
        btnStart = findViewById(R.id.btnStart)
        btnPause = findViewById(R.id.btnPause)
        btnReset = findViewById(R.id.btnReset)

        btnStart.setOnClickListener {
            if (!isRunning) {
                startTime = System.currentTimeMillis() - elapsedTime
                handler.post(runnable)
                isRunning = true
            }
        }

        btnPause.setOnClickListener {
            if (isRunning) {
                elapsedTime = System.currentTimeMillis() - startTime
                handler.removeCallbacks(runnable)
                isRunning = false
            }
        }

        btnReset.setOnClickListener {
            handler.removeCallbacks(runnable)
            isRunning = false
            elapsedTime = 0L
            tvTimer.text = "00:00:000"
        }
    }

    private val runnable: Runnable = object : Runnable {
        override fun run() {
            val currentTime = System.currentTimeMillis()
            val time = currentTime - startTime

            val seconds = (time / 1000) % 60
            val minutes = (time / 1000) / 60
            val milliseconds = time % 1000

            tvTimer.text = String.format("%02d:%02d:%03d", minutes, seconds, milliseconds)

            handler.postDelayed(this, 10)
        }
    }
}
